# Aevron Bot — Railway Deploy Rehberi

## 1. GitHub'a Yükle

```bash
git init
git add .
git commit -m "Aevron Bot ilk commit"
# GitHub'da yeni repo oluştur, sonra:
git remote add origin https://github.com/KULLANICI/aevron-bot.git
git push -u origin main
```

## 2. Railway'de Proje Oluştur

1. https://railway.app → **New Project**
2. **Deploy from GitHub repo** → repo'yu seç
3. Railway otomatik build başlatır

## 3. Railway'de Environment Variables Ekle

Railway panelinde **Variables** sekmesine git, şunları ekle:

| Değişken                | Değer                                          |
|-------------------------|------------------------------------------------|
| `DISCORD_TOKEN`         | Discord Developer Portal'daki Bot Token        |
| `CLIENT_ID`             | Uygulamanın Application ID'si                  |
| `DISCORD_CLIENT_SECRET` | OAuth2 → Client Secret                         |
| `REDIRECT_URI`          | `https://RAILWAY_URL/auth/callback`            |
| `SESSION_SECRET`        | Rastgele uzun bir şifre (en az 32 karakter)    |
| `NODE_ENV`              | `production`                                   |

> **RAILWAY_URL:** Railway'in sana verdiği URL (örn: `aevron-bot.up.railway.app`)  
> Settings → Networking → Public Domain'den kopyala.

## 4. Discord Developer Portal Ayarları

1. https://discord.com/developers/applications → Uygulamanı seç
2. **OAuth2 → General** → Redirects:
   - `https://RAILWAY_URL/auth/callback` ekle ✅
3. **Bot** → Privileged Gateway Intents:
   - ✅ SERVER MEMBERS INTENT
   - ✅ MESSAGE CONTENT INTENT

## 5. Netlify'daki HTML'leri Güncelle

`login.html` ve `dashboard.html` içinde `localhost:3000` geçen yerleri Railway URL'nle değiştir.  
Zaten Socket.io ve API çağrıları relative path (`/api/...`) kullandığı için HTML'leri  
**Railway'in kendi domain'inden** servis edersen hiç değiştirmene gerek yok.

> **Öneri:** HTML'leri ayrı Netlify'a atmak yerine, Railway'in kendisinden sun.  
> `public/` klasörü zaten Express tarafından static olarak servis ediliyor.  
> Sadece `https://RAILWAY_URL` adresine git — her şey çalışır.

## Dosya Yapısı

```
files/
├── src/
│   ├── index.js       ← Giriş noktası
│   ├── bot.js         ← Discord bot
│   ├── web.js         ← Express + Socket.io
│   └── tokenStore.js  ← Token yönetimi
├── public/
│   ├── login.html     ← Giriş sayfası
│   └── dashboard.html ← Kontrol paneli
├── railway.json       ← Railway deploy config
├── Procfile           ← Start komutu
├── .gitignore
└── package.json
```
