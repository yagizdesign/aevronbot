/**
 * tokenStore.js
 * Kullanıcı tokenlarını bellekte tutar.
 * Üretimde bunu bir veritabanı (SQLite, MongoDB vb.) ile değiştir.
 *
 * Yapı:
 *   discordUserId  → { token, discordUserId, username, createdAt }
 *   token          → discordUserId   (ters arama için)
 */

const crypto = require('crypto');

const byUserId = new Map(); // userId  → kayıt
const byToken  = new Map(); // token   → userId

/** Kullanıcıya yeni token üret (varsa eskisini sil). */
function generateToken(userId, username) {
  // Eskiyi temizle
  const existing = byUserId.get(userId);
  if (existing) byToken.delete(existing.token);

  // Kriptografik olarak güvenli, tahmin edilemez token
  const token = crypto.randomBytes(32).toString('hex');

  const record = { token, discordUserId: userId, username, createdAt: Date.now() };
  byUserId.set(userId, record);
  byToken.set(token, userId);

  return token;
}

/** Token ile kayıt getir. */
function getByToken(token) {
  const userId = byToken.get(token);
  if (!userId) return null;
  return byUserId.get(userId) || null;
}

/** userId ile kayıt getir. */
function getByUserId(userId) {
  return byUserId.get(userId) || null;
}

/** Token geçerli mi? */
function isValid(token) {
  return byToken.has(token);
}

module.exports = { generateToken, getByToken, getByUserId, isValid };
