const {
  Client,
  GatewayIntentBits,
  Partials,
  PermissionFlagsBits,
  EmbedBuilder,
} = require('discord.js');

const { generateToken } = require('./tokenStore');

const BOT_ROLE_NAME = 'Bot Roles';

let client;

async function startBot() {
  client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.DirectMessages,
    ],
    partials: [Partials.Channel, Partials.Message],
  });

  // ── Hazır ──────────────────────────────────────────────────────────────────
  client.once('ready', async () => {
    console.log(`✅  Bot giriş yaptı: ${client.user.tag}`);

    // Bot'un bulunduğu her sunucuda "Bot Roles" rolünü oluştur (yoksa)
    for (const guild of client.guilds.cache.values()) {
      await ensureBotRole(guild);
    }
  });

  // Yeni sunucuya katılınca da rol oluştur
  client.on('guildCreate', async (guild) => {
    console.log(`📥  Yeni sunucu: ${guild.name}`);
    await ensureBotRole(guild);
  });

  // ── Mesaj dinle ────────────────────────────────────────────────────────────
  client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (!message.content.startsWith('b!')) return;

    const args    = message.content.slice(2).trim().split(/\s+/);
    const command = args[0].toLowerCase();

    // ── b!tokens ────────────────────────────────────────────────────────────
    if (command === 'tokens') {
      // Sadece sunucu içinde çalışır
      if (!message.guild) {
        return message.reply('❌ Bu komut sunucu kanalında kullanılmalı.');
      }

      const member = message.member;

      // "Bot Roles" rolü var mı kontrol et
      const botRole = message.guild.roles.cache.find(r => r.name === BOT_ROLE_NAME);
      if (!botRole) {
        return message.reply(`❌ Bu sunucuda \`${BOT_ROLE_NAME}\` rolü bulunamadı.`);
      }

      if (!member.roles.cache.has(botRole.id)) {
        return message.reply(`❌ Bu komutu kullanmak için **${BOT_ROLE_NAME}** rolüne sahip olmalısın.`);
      }

      // Token üret
      const token = generateToken(message.author.id, message.author.username);

      // DM gönder
      try {
        const embed = new EmbedBuilder()
          .setTitle('🔑 Panel Token\'ın')
          .setDescription(
            `Aşağıdaki token'ı web paneline giriş yaparken kullan.\n\n` +
            `\`\`\`\n${token}\n\`\`\`\n\n` +
            `⚠️ **Bu token'ı kimseyle paylaşma!** Her \`b!tokens\` komutunda yeni token üretilir ve eskisi geçersiz kalır.`
          )
          .setColor(0x5865F2)
          .setTimestamp()
          .setFooter({ text: 'Panel: http://localhost:3000' });

        await message.author.send({ embeds: [embed] });
        await message.reply('✅ Token\'ın DM\'e gönderildi!');
      } catch {
        await message.reply('❌ DM gönderemedim. DM\'lerini açık tuttuğundan emin ol.');
      }
    }

    // ── b!yardım ────────────────────────────────────────────────────────────
    if (command === 'yardım' || command === 'help') {
      const embed = new EmbedBuilder()
        .setTitle('📋 Komutlar')
        .addFields(
          { name: '`b!tokens`', value: 'Web panel token\'ı oluştur (DM ile gönderilir)' },
          { name: '`b!yardım`', value: 'Bu mesajı göster' }
        )
        .setColor(0x5865F2);
      message.reply({ embeds: [embed] });
    }
  });

  await client.login(process.env.DISCORD_TOKEN);
}

/** Sunucuda "Bot Roles" rolü yoksa oluştur. */
async function ensureBotRole(guild) {
  try {
    const existing = guild.roles.cache.find(r => r.name === BOT_ROLE_NAME);
    if (existing) {
      console.log(`  ✔ "${BOT_ROLE_NAME}" zaten var → ${guild.name}`);
      return existing;
    }

    const role = await guild.roles.create({
      name: BOT_ROLE_NAME,
      color: 0x5865F2,
      reason: 'Bot panel erişimi için otomatik oluşturuldu',
      permissions: [],
    });

    console.log(`  ✚ "${BOT_ROLE_NAME}" oluşturuldu → ${guild.name}`);
    return role;
  } catch (err) {
    console.error(`  ✖ Rol oluşturulamadı (${guild.name}):`, err.message);
  }
}

function getClient() {
  return client;
}

module.exports = { startBot, getClient };
