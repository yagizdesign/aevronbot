require('dotenv').config();
const { startBot, getClient } = require('./bot');
const { startWeb }            = require('./web');

(async () => {
  console.log('🤖  Bot başlatılıyor...');
  await startBot();

  console.log('🌐  Web paneli başlatılıyor...');
  startWeb(getClient);
})();
