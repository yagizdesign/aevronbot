const express    = require('express');
const session    = require('express-session');
const { Server } = require('socket.io');
const http       = require('http');
const path       = require('path');
const axios      = require('axios');

const { isValid, getByToken } = require('./tokenStore');

const DISCORD_API = 'https://discord.com/api/v10';
const SCOPES      = 'identify guilds';

function startWeb(getClient) {
  const app    = express();
  const server = http.createServer(app);
  const io     = new Server(server, {
    // Railway'de WebSocket için
    transports: ['websocket', 'polling'],
  });
  const PORT = process.env.PORT || 3000;

  // Railway proxy arkasında HTTPS'i doğru algıla
  app.set('trust proxy', 1);

  // ── Middleware ─────────────────────────────────────────────────────────────
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use(express.static(path.join(__dirname, '..', 'public')));

  const isProduction = process.env.NODE_ENV === 'production' ||
                       !!process.env.RAILWAY_STATIC_URL;

  app.use(session({
    secret: process.env.SESSION_SECRET || 'gelistirme-sifresi',
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge:   1000 * 60 * 60 * 24, // 1 gün
      secure:   isProduction,         // Railway'de HTTPS zorunlu
      httpOnly: true,
      sameSite: isProduction ? 'none' : 'lax',
    },
  }));

  // ── Auth guard ─────────────────────────────────────────────────────────────
  function requireAuth(req, res, next) {
    if (req.session?.user) return next();
    res.redirect('/login');
  }

  // ── Sayfalar ───────────────────────────────────────────────────────────────
  app.get('/',      requireAuth, (req, res) =>
    res.sendFile(path.join(__dirname, '..', 'public', 'dashboard.html')));

  app.get('/login', (req, res) =>
    res.sendFile(path.join(__dirname, '..', 'public', 'login.html')));

  // ── Token girişi ───────────────────────────────────────────────────────────
  app.post('/auth/token', (req, res) => {
    const { token } = req.body;
    if (!token || !isValid(token))
      return res.status(401).json({ error: 'Geçersiz token.' });

    const record = getByToken(token);
    req.session.user = {
      discordUserId: record.discordUserId,
      username:      record.username,
      token,
      loginMethod:   'token',
    };
    res.json({ ok: true });
  });

  // ── Discord OAuth2 ─────────────────────────────────────────────────────────
  app.get('/auth/discord', (req, res) => {
    const redirectUri = process.env.REDIRECT_URI;
    const params = new URLSearchParams({
      client_id:     process.env.CLIENT_ID,
      redirect_uri:  redirectUri,
      response_type: 'code',
      scope:         SCOPES,
    });
    res.redirect(`https://discord.com/oauth2/authorize?${params}`);
  });

  app.get('/auth/callback', async (req, res) => {
    const { code } = req.query;
    if (!code) return res.redirect('/login?error=no_code');

    try {
      const redirectUri = process.env.REDIRECT_URI;

      const tokenRes = await axios.post(
        `${DISCORD_API}/oauth2/token`,
        new URLSearchParams({
          client_id:     process.env.CLIENT_ID,
          client_secret: process.env.DISCORD_CLIENT_SECRET,
          grant_type:    'authorization_code',
          code,
          redirect_uri:  redirectUri,
        }),
        { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
      );

      const { access_token } = tokenRes.data;

      const userRes = await axios.get(`${DISCORD_API}/users/@me`, {
        headers: { Authorization: `Bearer ${access_token}` },
      });

      const discordUser = userRes.data;
      const pendingToken = req.session.pendingToken || '';
      const record = getByToken(pendingToken);

      req.session.user = {
        discordUserId:  discordUser.id,
        username:       discordUser.username,
        avatar:         discordUser.avatar,
        discordToken:   access_token,
        loginMethod:    'oauth',
        tokenVerified:  record?.discordUserId === discordUser.id,
      };
      delete req.session.pendingToken;

      res.redirect('/');
    } catch (err) {
      console.error('OAuth hatası:', err.response?.data || err.message);
      res.redirect('/login?error=oauth_failed');
    }
  });

  // Token + OAuth eşleştirme
  app.post('/auth/link-token', (req, res) => {
    const { token } = req.body;
    if (!isValid(token)) return res.status(401).json({ error: 'Geçersiz token.' });
    req.session.pendingToken = token;
    res.json({ ok: true, redirectTo: '/auth/discord' });
  });

  // ── Logout ─────────────────────────────────────────────────────────────────
  app.get('/logout', (req, res) => {
    req.session.destroy(() => res.redirect('/login'));
  });

  // ── API ────────────────────────────────────────────────────────────────────
  app.get('/api/me', requireAuth, (req, res) => {
    res.json(req.session.user);
  });

  app.get('/api/status', requireAuth, (req, res) => {
    const client = getClient();
    if (!client?.isReady()) return res.json({ online: false });

    const guilds = client.guilds.cache.map(g => ({
      id:      g.id,
      name:    g.name,
      icon:    g.iconURL(),
      members: g.memberCount,
    }));

    res.json({
      online:     true,
      tag:        client.user.tag,
      avatar:     client.user.displayAvatarURL(),
      guildCount: guilds.length,
      guilds,
    });
  });

  app.get('/api/guilds/:guildId/channels', requireAuth, (req, res) => {
    const client  = getClient();
    const guild   = client?.guilds.cache.get(req.params.guildId);
    if (!guild) return res.status(404).json({ error: 'Sunucu bulunamadı.' });

    const channels = guild.channels.cache
      .filter(c => c.isTextBased && c.isTextBased())
      .map(c => ({ id: c.id, name: c.name, type: c.type }));

    res.json(channels);
  });

  app.post('/api/send', requireAuth, async (req, res) => {
    const { guildId, channelId, content } = req.body;
    if (!content?.trim())
      return res.status(400).json({ error: 'Mesaj boş olamaz.' });

    const client  = getClient();
    const guild   = client?.guilds.cache.get(guildId);
    const channel = guild?.channels.cache.get(channelId);

    if (!channel) return res.status(404).json({ error: 'Kanal bulunamadı.' });

    try {
      const msg = await channel.send(content);
      io.emit('message_sent', {
        guildId, channelId, content,
        sentBy: req.session.user.username,
        time:   new Date().toISOString(),
        msgId:  msg.id,
      });
      res.json({ ok: true, msgId: msg.id });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Mesaj gönderilemedi: ' + err.message });
    }
  });

  // ── Hata yakalama ──────────────────────────────────────────────────────────
  app.use((err, req, res, _next) => {
    console.error(err);
    res.status(500).json({ error: 'Sunucu hatası.' });
  });

  // ── Başlat ─────────────────────────────────────────────────────────────────
  server.listen(PORT, '0.0.0.0', () => {
    const url = process.env.RAILWAY_STATIC_URL
      ? `https://${process.env.RAILWAY_STATIC_URL}`
      : `http://localhost:${PORT}`;
    console.log(`✅  Web panel: ${url}`);
  });

  return { io };
}

module.exports = { startWeb };
